<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            Sidebar
        </div>

        <div class="card-body">
            <ul class="list-unstyled text-small" role="tablist">
                <li class="nav-link" role="presentation">
                    <a href="<?php echo e(url('/admin')); ?>">
                        Dashboard
                    </a>
                </li>
                <li class="nav-link" role="presentation">
                    <a href="<?php echo e(url('/admin/role')); ?>">
                        Role
                    </a>
                </li>
                <li class="nav-link" role="presentation">
                    <a href="<?php echo e(url('/admin/permission')); ?>">
                        Permission
                    </a>
                </li>
                <li class="nav-link" role="presentation">
                    <a href="<?php echo e(url('/admin/user')); ?>">
                        Users
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>